<?php

return [
    'name' => 'InAppLiveClass'
];
