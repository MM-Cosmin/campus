<?php

namespace Modules\InAppLiveClass\Entities;

use Illuminate\Database\Eloquent\Model;

class InAppLiveClassMeetingUser extends Model
{
    protected $guarded = [];
}
