<?php
namespace Modules\Zoom\Repositories\Interfaces;

interface ReportRepositoryInterface
{
    public function classReports();
    public function meetingReports();
}
