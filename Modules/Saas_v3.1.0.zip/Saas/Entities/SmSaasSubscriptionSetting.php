<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class SmSaasSubscriptionSetting extends Model
{
    protected $fillable = [];
}
