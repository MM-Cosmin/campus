<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class AdditionalServices extends Model
{
    protected $fillable = [];
}
