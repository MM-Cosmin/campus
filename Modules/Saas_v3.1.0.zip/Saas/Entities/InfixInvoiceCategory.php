<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class InfixInvoiceCategory extends Model
{
    protected $fillable = [];
}
