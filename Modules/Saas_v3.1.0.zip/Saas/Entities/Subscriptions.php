<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class subscriptions extends Model
{
    protected $fillable = [];
}
