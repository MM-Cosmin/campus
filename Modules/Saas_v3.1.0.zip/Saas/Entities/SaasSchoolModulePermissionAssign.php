<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class SaasSchoolModulePermissionAssign extends Model
{
    protected $fillable = [];
}
