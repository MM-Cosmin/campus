<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class Billing_Information extends Model
{
    protected $fillable = [];
}
