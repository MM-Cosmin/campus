<?php

namespace Modules\Saas\Entities;

use Illuminate\Database\Eloquent\Model;

class SmSaasPackages extends Model
{
    protected $fillable = [];
}
