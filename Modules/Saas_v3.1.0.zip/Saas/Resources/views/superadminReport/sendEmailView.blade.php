{{ $compact['description'] }}
