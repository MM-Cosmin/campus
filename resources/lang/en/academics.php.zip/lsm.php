<?php
    return [    "In Minute" => "In Minute",
    "Others" => "Others",
        ]
?>