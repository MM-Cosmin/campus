<?php 
return [
   'notification'=>'Notification',
   'notifications'=>'Notifications',
   'notification_list'=>'Notification List',
   'ago'=>'ago',
   'view_details'=>'View Details',
];